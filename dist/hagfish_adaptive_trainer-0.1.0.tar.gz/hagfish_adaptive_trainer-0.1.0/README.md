# hagfish-adaptive-trainer

Adaptive Training Budget Optimization for supervised ML models using a bandit-based agentic framework. The package provides a planner, critic, memory, and an optimizer loop to experiment with training budget allocation strategies.

## Installation

pip install adaptive-trainer

## Usage

from hagfish-adaptive-trainer import AdaptiveTrainer
trainer = AdaptiveTrainer(alpha=1e-4)
